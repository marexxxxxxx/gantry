import torch  # noqa: F401  — loads libc10/libtorch before _C links against them

from . import _C  # noqa: E402,F401  — registers torch.ops.escha.*

try:  # noqa: E402
    from importlib.metadata import PackageNotFoundError, version as _version

    __version__ = _version("escha")
except PackageNotFoundError:  # not pip-installed (e.g. run from a source tree)
    __version__ = "unknown"

__all__ = ["__version__"]
