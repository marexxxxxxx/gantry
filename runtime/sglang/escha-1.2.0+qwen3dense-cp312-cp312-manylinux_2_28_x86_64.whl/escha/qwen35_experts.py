"""Packed-codes (memory-frugal) Qwen3.5/3.6 MoE routed experts for E2E fine-tuning.

The hybrid Qwen3_5-MoE model (`Qwen3_5MoeForConditionalGeneration`, e.g.
Qwen3.6-35B-A3B) is ~70 GB bf16 — far too large to hold resident on the L40S
(44.4 GB usable) for E2E backprop. This module is the MoE analogue of the dense
ESCHA ``ScaledLinear`` E2E path and a direct sibling of
``gptoss_packed_experts.PackedGptOssExperts``: each routed expert's quantized
weight is stored as its **code CODES** (~few MB vs ~tens of MB bf16) and
**decoded on the fly** every forward, so the whole layer's routed experts fit in
a few GB and E2E trains only the tiny per-expert ``s_in``/``s_out`` scales
(+ optional ``bcorr``).

Differences from the gpt-oss packed experts (the silent-corruptor list — get any
of these wrong and the experts are numerically wrong with NO error):

* **Contiguous SwiGLU, plain SiLU.** Qwen3_5MoeExperts.forward is
  ``gate, up = linear(x, gate_up_proj[e]).chunk(2, dim=-1); act_fn(gate) * up`` —
  a CONTIGUOUS ``chunk(2)`` (first half = gate, second half = up) and a plain
  ``SiLU(gate) * up``. gpt-oss instead does an INTERLEAVED ``[..., ::2]/[1::2]``
  split with ``clamp(±limit)`` + ``sigmoid(alpha*gate)`` + ``(up + 1) * glu`` and
  a per-output bias. None of that applies here.
* **No expert bias.** ``gate_up_proj``/``down_proj`` are bare 3-D
  ``nn.Parameter`` with no bias term.
* **The SHARED expert is NOT part of this module.** Qwen3_5MoeSparseMoeBlock owns
  a separate dense ``shared_expert`` (a ``Qwen3_5MoeMLP``) and a
  ``shared_expert_gate`` whose ``sigmoid``-gated output is ADDED to the routed
  output. This module replaces ONLY ``block.experts`` (the routed packed
  experts); the caller keeps ``shared_expert`` / ``shared_expert_gate`` / ``gate``
  intact, so the shared path and the (un-renormalised, ``norm_topk_prob=False``)
  routing weights are handled by the original block.

Qwen3_5-MoE dims (hidden 2048-class, ``moe_intermediate_size``, ``2*I``) are
multiples of the ref transform width (128), so unlike gpt-oss's IC=2880 there is
NO padding — ``in_p == in_f`` and ``out_p == out_f``. ``PackedScaledExpertLinear``
still handles the general (padded) case; here it is simply a no-op.

The codes are FROZEN; gradient flows only to the per-expert scales, which are
applied *after* the non-differentiable decode, exactly as in the gpt-oss and
dense ESCHA E2E paths.
"""

from __future__ import annotations

import logging
import os

import torch
import torch.nn as nn
import torch.nn.functional as F

# Reuse the generic decode-on-the-fly expert projection (codes-in / scaled fp16
# out) verbatim — it is architecture-agnostic. _round_up is the /128 pad helper.
from escha.gptoss_experts import PackedScaledExpertLinear, _round_up

logger = logging.getLogger(__name__)


def _debug_dir() -> str:
    """Directory for the opt-in MoE debug/status files.

    ``ESCHA_MOE_DEBUG_DIR`` overrides it; otherwise the system temp dir. Never a
    hardcoded absolute path — this module ships inside the released runtime wheel.
    """
    import os as _os
    import tempfile as _tf

    d = _os.environ.get("ESCHA_MOE_DEBUG_DIR") or _os.path.join(_tf.gettempdir(), "escha_moe")
    _os.makedirs(d, exist_ok=True)
    return d



@torch.no_grad()
def _sort_by_expert(top_k_index: torch.Tensor, top_k_weights: torch.Tensor,
                    num_experts: int):
    """Group routed (token, slot) pairs by expert via a single argsort — the fused-dispatch
    replacement for the per-expert ``one_hot``/``where`` loop driver.

    Returns ``(token_sorted, weight_sorted, expert_count)``:
      * ``token_sorted`` [M] int64 — token ids ordered so all of expert e's tokens are contiguous.
      * ``weight_sorted`` [M] fp16 — the routing weight for each (token, slot), aligned to token_sorted.
      * ``expert_count`` [num_experts+1] — per-expert token counts; bucket ``num_experts`` collects any
        sentinel/out-of-range expert id (argsort puts it last, and the forward loop — ranging only over
        0..num_experts-1 — never slices it, exactly dropping those tokens like the old ``e == num_experts``
        ``continue``).
    M = N*top_k. Weights are taken AS-IS (norm_topk_prob=False — no renormalization).
    """
    N, top_k = top_k_index.shape
    dev = top_k_index.device
    flat_expert = top_k_index.reshape(-1)
    flat_weight = top_k_weights.reshape(-1).to(torch.float16)
    flat_token = torch.arange(N, device=dev).repeat_interleave(top_k)
    order = flat_expert.argsort()
    token_sorted = flat_token[order].contiguous()
    weight_sorted = flat_weight[order].contiguous()
    expert_count = torch.bincount(flat_expert, minlength=num_experts + 1)
    return token_sorted, weight_sorted, expert_count


class PackedQwen35MoeExperts(nn.Module):
    """Drop-in replacement for ``Qwen3_5MoeExperts`` (the routed packed experts)
    whose per-expert projections are :class:`PackedScaledExpertLinear` (frozen
    code codes + trainable ``s_in``/``s_out``).

    ``forward(hidden_states, top_k_index, top_k_weights)`` mirrors
    ``Qwen3_5MoeExperts.forward`` exactly (one-hot routing dispatch, contiguous
    ``chunk(2)`` + plain ``SiLU(gate) * up``, ``index_add`` accumulation) so it
    slots straight into ``Qwen3_5MoeSparseMoeBlock.forward`` for E2E training and
    serving. The block's shared-expert / gate / routing-weight handling is left
    untouched.
    """

    _is_qwen35_moe_packed = True

    def __init__(self, layer_codes: dict, cfg, *, bias_correction: bool = False):
        """``layer_codes`` is the saved per-layer routed-expert codes dict (the
        same schema the quant ``--save-codes`` path emits for gpt-oss): for each
        routed expert ``e`` a ``gate_up_proj_{e}`` and ``down_proj_{e}`` entry,
        each a dict with ``code`` (int16 codes), ``rin``, ``rout``, ``K``,
        ``codebook`` (``"cbA"``/``"mul1"``), and optional ``bias`` (ignored here —
        Qwen3_5 experts are bias-free).

        ``cfg`` is the model text config (``num_experts``, ``hidden_size``,
        ``moe_intermediate_size``).
        """
        super().__init__()
        # Qwen3_5 key is `num_experts` (NOT gpt-oss's `num_local_experts`).
        self.num_experts = int(cfg.num_experts)
        self.hidden_size = int(cfg.hidden_size)
        self.intermediate_size = int(cfg.moe_intermediate_size)
        H, I = self.hidden_size, self.intermediate_size
        Hp, Ip2, Ip = _round_up(H), _round_up(2 * I), _round_up(I)
        if (Hp, Ip2, Ip) != (H, 2 * I, I):
            # Informational only — PackedScaledExpertLinear pads/truncates safely.
            logger.debug("Qwen3_5 MoE dims not /128-aligned (H=%d 2I=%d I=%d); "
                         "decode will pad to (%d,%d,%d).", H, 2 * I, I, Hp, Ip2, Ip)

        self.gate_up_experts = nn.ModuleDict()
        self.down_experts = nn.ModuleDict()
        for e in range(self.num_experts):
            gu = layer_codes[f"gate_up_proj_{e}"]
            dp = layer_codes[f"down_proj_{e}"]
            self.gate_up_experts[f"gate_up_proj_{e}"] = PackedScaledExpertLinear(
                gu["code"], gu["rin"], gu["rout"], None,
                in_f=H, out_f=2 * I, in_p=Hp, out_p=Ip2,
                K=gu["K"], cbA=(gu["codebook"] == "cbA"),
                mul1=(gu["codebook"] == "mul1"), bias_correction=bias_correction)
            self.down_experts[f"down_proj_{e}"] = PackedScaledExpertLinear(
                dp["code"], dp["rin"], dp["rout"], None,
                in_f=I, out_f=H, in_p=Ip, out_p=Hp,
                K=dp["K"], cbA=(dp["codebook"] == "cbA"),
                mul1=(dp["codebook"] == "mul1"), bias_correction=bias_correction)

    @staticmethod
    def _apply_gate(gate_up: torch.Tensor) -> torch.Tensor:
        """Contiguous SwiGLU: first half = gate, second half = up; plain SiLU.

        Matches ``Qwen3_5MoeExperts.forward``'s ``act_fn(gate) * up`` after a
        contiguous ``chunk(2, dim=-1)`` — deliberately NOT the gpt-oss interleaved
        / clamped / ``(up+1)`` form.
        """
        gate, up = gate_up.chunk(2, dim=-1)
        return F.silu(gate) * up

    def forward(self, hidden_states: torch.Tensor, top_k_index: torch.Tensor,
                top_k_weights: torch.Tensor) -> torch.Tensor:
        # Training/autograd: keep the differentiable one-hot loop (E2E trains the per-expert scales,
        # whose grad flows through this dispatch). Serving/eval (no grad): the sorted-grouped dispatch —
        # bit-comparable (same ref_gemm decode + _apply_gate + as-is weight + index_add) but it drops
        # the 256-wide one_hot and the per-expert torch.where, and feeds each expert one contiguous
        # token block (one larger GEMM) instead of a scattered per-token gather.
        if torch.is_grad_enabled():
            return self._forward_loop(hidden_states, top_k_index, top_k_weights)
        import os as _os
        if (_os.environ.get("ESCHA_MOE_DEBUG") and not getattr(self, "_dbg_done", False)
                and hidden_states.shape[0] <= 64):     # fire on a DECODE-sized forward, not prefill
            self._dbg_done = True
            try:
                yl = self._forward_loop(hidden_states, top_k_index, top_k_weights)
                ys = self._forward_sorted(hidden_states, top_k_index, top_k_weights)
                if getattr(self, "_ref_moe_ok", None) is None:
                    self._build_ref_moe()
                ym = (self._forward_ref_moe(hidden_states, top_k_index, top_k_weights)
                      if self._ref_moe_ok else None)
                def _df(a, b):
                    return float((a.float() - b.float()).abs().max()) if b is not None else -1.0
                with open(_os.path.join(_debug_dir(), "_moe_debug.txt"), "a") as fh:
                    fh.write(f"hs={tuple(hidden_states.shape)}/{hidden_states.dtype} "
                             f"ti={tuple(top_k_index.shape)}/{top_k_index.dtype} "
                             f"tw={tuple(top_k_weights.shape)}/{top_k_weights.dtype} "
                             f"ti[min,max]=[{int(top_k_index.min())},{int(top_k_index.max())}] "
                             f"E={self.num_experts} | loop_vs_sorted={_df(yl, ys):.5f} "
                             f"loop_vs_moe={_df(yl, ym):.5f} ref_ok={self._ref_moe_ok} "
                             f"||loop||={float(yl.abs().mean()):.5f}\n")
            except Exception as _ex:
                with open(_os.path.join(_debug_dir(), "_moe_debug.txt"), "a") as fh:
                    fh.write(f"DEBUG EXC: {type(_ex).__name__}: {_ex}\n")
            return yl
        # Parity/debug: force the the reference codec per-expert reference decode (ref_gemm).
        if os.environ.get("ESCHA_FORCE_SORTED_MOE"):
            return self._forward_sorted(hidden_states, top_k_index, top_k_weights)
        # Serving/eval dispatch preference:
        #   1. cleanroom escha escham_moe (dep-free, no 5GB code dup → fits 24GB) when
        #      ESCHA_USE_ESCHAM_MOE is set OR ref_moe is unavailable/ineligible;
        #   2. else the reference codec fused ref_moe (needs the ~5GB split copies);
        #   3. else the bit-validated per-expert sorted dispatch.
        if getattr(self, "_ref_moe_ok", None) is None:
            self._build_ref_moe()
            if not getattr(self, "_dq_status_logged", False):   # one-shot durable status (serving_perf_notes.md rule)
                self._dq_status_logged = True
                try:
                    with open(os.path.join(_debug_dir(), "_ref_moe_status.txt"), "a") as _fh:
                        _fh.write("build: _ref_moe_ok=%s H=%d I=%d E=%d\n"
                                  % (self._ref_moe_ok, self.hidden_size, self.intermediate_size, self.num_experts))
                except Exception:
                    pass
        prefer_escha = bool(os.environ.get("ESCHA_USE_ESCHAM_MOE")) or not self._ref_moe_ok
        if prefer_escha:
            if getattr(self, "_escha_moe_ok", None) is None:
                self._escha_moe_ok = self._check_escha_moe()
            if self._escha_moe_ok:
                if getattr(self, "_escha_fused_ok", None) is None:
                    self._escha_fused_ok = hasattr(torch.ops.escha, "escham_moe_linear")
                try:
                    if self._escha_fused_ok:
                        return self._forward_fused_oom_safe(
                            hidden_states, top_k_index, top_k_weights)
                    return self._forward_escha_moe(hidden_states, top_k_index, top_k_weights)
                except torch.OutOfMemoryError:
                    # Genuinely out of memory even at the minimum split -- nothing left to
                    # try. Re-raise regardless of REQUIRE_FUSED: a sorted-dispatch fallback
                    # would need MORE memory, not less.
                    raise
                except Exception:
                    logger.warning("escha escham_moe failed — falling back", exc_info=True)
                    if os.environ.get("ESCHA_MOE_REQUIRE_FUSED"):
                        raise      # surface the real cause instead of a sorted-dispatch
                                   # fallback that needs the reference codec
                    self._escha_moe_ok = False
        if self._ref_moe_ok:
            try:
                return self._forward_ref_moe(hidden_states, top_k_index, top_k_weights)
            except Exception:
                import os as _os, traceback as _tb
                try:
                    with open(os.path.join(_debug_dir(), "_ref_moe_status.txt"), "a") as _fh:
                        _fh.write("FUSED FORWARD EXC:\n" + _tb.format_exc() + "\n")
                except Exception:
                    pass
                logger.error("ref_moe forward failed — falling back to sorted dispatch", exc_info=True)
                if _os.environ.get("ESCHA_MOE_REQUIRE_FUSED"):
                    raise                                        # surface the real cause instead of silent 40x slowdown
                self._ref_moe_ok = False
        return self._forward_sorted(hidden_states, top_k_index, top_k_weights)

    @staticmethod
    def _check_escha_moe() -> bool:
        """escha escham_moe path needs escha + CUDA. Gate on EITHER op the forward can use:
        the fused Step-B ``escham_moe_linear`` (preferred by forward()) OR the per-expert Step-A
        ``escham_decode_gemv`` — gating only on the latter wrongly disables the fused path if a build
        ships just ``escham_moe_linear`` (silently falling back to sorted dispatch)."""
        try:
            import escha  # noqa: F401
            return bool(torch.cuda.is_available()) and (
                hasattr(torch.ops.escha, "escham_moe_linear")
                or hasattr(torch.ops.escha, "escham_decode_gemv")
            )
        except Exception:
            return False

    @torch.no_grad()
    def _forward_sorted(self, hidden_states: torch.Tensor, top_k_index: torch.Tensor,
                        top_k_weights: torch.Tensor) -> torch.Tensor:
        final_hidden_states = torch.zeros_like(hidden_states)
        token_sorted, weight_sorted, expert_count = _sort_by_expert(
            top_k_index, top_k_weights, self.num_experts)
        counts = expert_count.tolist()                 # one D2H sync (vs per-expert .item())
        cursor = 0
        for e in range(self.num_experts):
            cnt = counts[e]
            if cnt == 0:                               # cold expert: no kernel launch
                continue
            idx = token_sorted[cursor:cursor + cnt]    # contiguous token block for expert e
            w = weight_sorted[cursor:cursor + cnt]     # fp16 routing weights, aligned to idx
            cursor += cnt
            cur = hidden_states.index_select(0, idx)   # [cnt, H]
            gate_up = self.gate_up_experts[f"gate_up_proj_{e}"](cur)
            gated = self._apply_gate(gate_up)
            out = self.down_experts[f"down_proj_{e}"](gated)
            out = out * w[:, None].to(out.dtype)       # norm_topk_prob=False → weight as-is
            final_hidden_states.index_add_(0, idx, out.to(final_hidden_states.dtype))
        return final_hidden_states

    # ---- cleanroom escha escham_moe path (dependency-free, no code duplication) ----

    @staticmethod
    def _escham_linear(op, x: torch.Tensor, mod, out_features: int) -> torch.Tensor:
        """One quantized Linear via escha's escham_decode_gemv, M-chunked to the kernel's
        M<=8. Reads ``mod.code`` directly (the MERGED gate_up code decodes to the
        full [.,2I] output; the SwiGLU split is applied to the OUTPUT) — no code copy."""
        K = mod.code.shape[-1] // 16
        s_in = mod.s_in.detach().float().contiguous()
        s_out = mod.s_out.detach().float().contiguous()
        rin, rout = mod.rin_buf, mod.rout_buf
        cbA, mul1 = bool(mod._cbA), bool(mod._mul1)
        n = x.shape[0]
        if n <= 8:
            return op(x.contiguous(), mod.code, rin, rout, s_in, s_out,
                      out_features, K, cbA, mul1)
        outs = [op(x[s:s + 8].contiguous(), mod.code, rin, rout, s_in, s_out,
                   out_features, K, cbA, mul1) for s in range(0, n, 8)]
        return torch.cat(outs, 0)

    @torch.no_grad()
    def _forward_escha_moe(self, hidden_states: torch.Tensor, top_k_index: torch.Tensor,
                           top_k_weights: torch.Tensor) -> torch.Tensor:
        """Cleanroom fused-MoE via escha ``escham_decode_gemv`` per expert. Decodes the
        MERGED gate_up code at OC=2I (SwiGLU splits the output) — NO per-expert
        gate/up duplication, so it fits a 24GB 4090. Dependency-free; reuses the
        bit-exact escham decode-GEMV. Same routing/scatter as _forward_sorted."""
        import escha  # noqa: F401  (registers torch.ops.escha.escham_*)
        op = torch.ops.escha.escham_decode_gemv
        H, I = self.hidden_size, self.intermediate_size
        final = torch.zeros_like(hidden_states)
        token_sorted, weight_sorted, expert_count = _sort_by_expert(
            top_k_index, top_k_weights, self.num_experts)
        counts = expert_count.tolist()
        cursor = 0
        for e in range(self.num_experts):
            cnt = counts[e]
            if cnt == 0:
                continue
            idx = token_sorted[cursor:cursor + cnt]
            w = weight_sorted[cursor:cursor + cnt]
            cursor += cnt
            cur = hidden_states.index_select(0, idx).to(torch.float16)        # [cnt, H]
            gu = self._escham_linear(op, cur, self.gate_up_experts[f"gate_up_proj_{e}"], 2 * I)
            gated = self._apply_gate(gu).to(torch.float16)                    # [cnt, I]
            out = self._escham_linear(op, gated, self.down_experts[f"down_proj_{e}"], H)
            out = out * w[:, None].to(out.dtype)
            final.index_add_(0, idx, out.to(final.dtype))
        return final

    # ---- fused escha escham_moe path (Step B): 2 grouped kernels/Linear, no 5GB dup ----

    def _build_escha_moe(self) -> None:
        """Stack the small per-expert scales [E,dim] and build per-expert MERGED-code
        int64 pointer arrays (NO copy — the ~5GB-free trick). Lazy, once per layer."""
        gus = list(self.gate_up_experts.values())
        dps = list(self.down_experts.values())
        dev = gus[0].code.device

        def sh(mods, a):
            return torch.stack([getattr(m, a) for m in mods]).contiguous()

        def sf(mods, a):
            return torch.stack([getattr(m, a).detach().float() for m in mods]).contiguous()

        self._gu_rin, self._gu_rout = sh(gus, "rin_buf"), sh(gus, "rout_buf")
        self._gu_ain, self._gu_aout = sf(gus, "s_in"), sf(gus, "s_out")
        self._dp_rin, self._dp_rout = sh(dps, "rin_buf"), sh(dps, "rout_buf")
        self._dp_ain, self._dp_aout = sf(dps, "s_in"), sf(dps, "s_out")
        self._gu_tr_keep = [m.code for m in gus]      # keep alive for the ptr array
        self._dp_tr_keep = [m.code for m in dps]
        self._gu_tr_ptrs = torch.tensor([t.data_ptr() for t in self._gu_tr_keep],
                                        dtype=torch.long, device=dev)
        self._dp_tr_ptrs = torch.tensor([t.data_ptr() for t in self._dp_tr_keep],
                                        dtype=torch.long, device=dev)
        self._gu_K = gus[0].code.shape[-1] // 16
        self._dp_K = dps[0].code.shape[-1] // 16
        self._moe_cbA, self._moe_mul1 = bool(gus[0]._cbA), bool(gus[0]._mul1)
        try:  # arch route (1=lovelace/sm_89 geometry, 2=blackwell/sm_120) — older builds lack the op
            route = {1: "lovelace", 2: "blackwell"}.get(int(torch.ops.escha.escham_route()), "?")
        except (AttributeError, RuntimeError):
            route = "pre-route build"
        logger.info("escha escham_moe fused MoE enabled (%d experts, K=%d, kernel route=%s)",
                    len(gus), self._gu_K, route)
        self._escha_built = True

    def _capturable_static_tensors(self, M, top_k, dev):
        """Routing-independent index tensors for the fixed-shape capturable path —
        cached per (M, device) so each layer forward stops re-launching arange/ones."""
        cache = getattr(self, "_cap_static", None)
        if cache is None:
            cache = self._cap_static = {}
        key = (int(M), str(dev))
        ent = cache.get(key)
        if ent is None:
            flat_token = torch.arange(M, device=dev) // top_k                # [M] int64
            rows = torch.arange(M, device=dev, dtype=torch.int32)
            cn_t = torch.ones(M, device=dev, dtype=torch.int32)
            ent = cache[key] = (flat_token, rows, cn_t)
        return ent

    @staticmethod
    def _has_fused_epi_ops():
        import escha  # noqa: F401
        return (
            hasattr(torch.ops.escha, "escham_moe_linear_swiglu")
            and hasattr(torch.ops.escha, "escham_route")
            and torch.ops.escha.escham_route() == 2          # blackwell route active
            and not os.environ.get("ESCHA_DISABLE_FUSED_EPI")
        )

    @staticmethod
    def _has_prehad_ops():
        import escha  # noqa: F401
        try:
            return (
                hasattr(torch.ops.escha, "escham_moe_linear_swiglu_t")
                and bool(torch.ops.escha.escham_moe_prehad_available())
                and not os.environ.get("ESCHA_DISABLE_PREHAD")
            )
        except (AttributeError, RuntimeError):
            return False

    @staticmethod
    def _has_prehad_k3_ops():
        """The fused prehad scatter accepts K=3 in this kernel build, letting a
        mixed-bit (K2 gate_up / K3 down) layer run the fused epilogue fast path
        (swiglu_t K2 -> scatter_prehad K3) instead of the generic butterfly+epi
        + Python-SwiGLU + index_add route. Opt-in via ESCHA_ENABLE_K3_FUSED_EPI=1;
        old builds lack the probe op -> hasattr False -> safe fallback."""
        import escha  # noqa: F401
        if os.environ.get("ESCHA_ENABLE_K3_FUSED_EPI") != "1":
            return False
        try:
            return (
                hasattr(torch.ops.escha, "escham_moe_prehad_k3_available")
                and bool(torch.ops.escha.escham_moe_prehad_k3_available())
            )
        except (AttributeError, RuntimeError):
            return False

    def _dedup_enabled(self):
        cached = getattr(self, "_dedup", None)
        if cached is None:
            # v4 (warp-autonomous experiment) assumes m == 1 per chunk;
            # dedup builds m > 1 chunks, so it is disabled under v4.
            cached = self._dedup = (
                hasattr(torch.ops.escha, "escham_moe_build_chunks")
                and not os.environ.get("ESCHA_DISABLE_DEDUP")
                and os.environ.get("ESCHA_ESCHAM_BW_V4") != "1"
            )
        return cached

    def _dedup_min_bs(self):
        cached = getattr(self, "_dedup_min", None)
        if cached is None:
            try:
                cached = int(os.environ.get("ESCHA_DEDUP_MIN_BS", "4"))
            except ValueError:
                cached = 4
            self._dedup_min = cached
        return cached

    @torch.no_grad()
    def _det_scatter(self):
        """Opt-in deterministic scatter (ZML back-port): the fused epilogue stores
        weighted per-row outputs and a combine kernel gathers them in fixed order —
        no torch::zeros pre-zero, no f16 atomics, batch-invariant MoE output.
        ESCHA_ENABLE_DET_SCATTER=1 + kernel capability probe."""
        v = getattr(self, "_det_scatter_en", None)
        if v is None:
            v = self._det_scatter_en = (
                os.environ.get("ESCHA_ENABLE_DET_SCATTER") == "1"
                and hasattr(torch.ops.escha, "escham_moe_linear_scatter_prehad_det"))
        return v

    def _forward_escha_moe_capturable(self, hidden_states, top_k_index, top_k_weights, op):
        """Sync-free, fixed-shape (M=N*top_k) MoE for CUDA-graph capture: per-row 1-row
        chunks (no argsort, no counts.tolist/.item, no dynamic grid). Each routed (token,
        slot) row looks up its own expert's code; at decode batch sizes experts get ~1
        row each so this matches the chunked path's efficiency. Numerically identical to
        _forward_escha_moe_fused (same kernel, same per-row decode).

        On the blackwell kernel route (RTX 50 / sm_100+) the gather, SwiGLU and the
        weighted scatter are fused into the two escham ops (escham_moe_linear_swiglu +
        escham_moe_linear_scatter): 4 kernels/layer instead of ~10. Disable with
        ESCHA_DISABLE_FUSED_EPI=1."""
        H, I, E = self.hidden_size, self.intermediate_size, self.num_experts
        dev = hidden_states.device
        N, top_k = top_k_index.shape
        M = N * top_k
        flat_expert = top_k_index.reshape(-1).to(torch.long)                 # [M]
        flat_weight = top_k_weights.reshape(-1)                              # [M]
        flat_token, rows, cn_t = self._capturable_static_tensors(M, top_k, dev)
        ce_t = flat_expert.to(torch.int32)                                   # per-row chunk = its expert

        fused = getattr(self, "_fused_epi", None)
        if fused is None:
            # The fused SwiGLU/scatter epilogue ops are the blackwell-route
            # (register/cp.async) kernels. The non-prehad fused scatter is K==2
            # only, but the PREHAD scatter now accepts K==3 (opt-in): a mixed-bit
            # K2-gate_up / K3-down layer fuses via swiglu_t(K2) -> scatter_prehad(K3),
            # avoiding the generic butterfly+epi + Python-SwiGLU + index_add route.
            # dp_K==3 REQUIRES the prehad ops (the non-prehad fused scatter is K2-only).
            dp_fusable = self._dp_K == 2 or (
                self._dp_K == 3 and self._has_prehad_k3_ops() and self._has_prehad_ops())
            fused = self._fused_epi = (
                self._has_fused_epi_ops() and self._gu_K == 2 and dp_fusable)
        if fused:
            x16 = hidden_states.to(torch.float16).contiguous()
            prehad = getattr(self, "_prehad", None)
            if prehad is None:
                prehad = self._prehad = self._has_prehad_ops()
            if prehad:
                # v3 handoff: the SwiGLU epilogue also emits the down-proj's
                # transform-transformed input, so the down gemv runs barrier-free.
                # At N >= ESCHA_DEDUP_MIN_BS (default 4), dedup rows by expert
                # first (graph-safe single-block builder): same-expert rows merge
                # into one <=8-row chunk, so the code is fetched + decoded once
                # per expert per layer. Measured on the 5060 Ti: bs8 -9% (uniform
                # routing) to -33% (hot-expert routing); at bs2 the 40 builder
                # launches/step outweigh the ~6% duplicate rate, hence the gate.
                if N >= self._dedup_min_bs() and self._dedup_enabled():
                    re_s, ce_s, cr0_s, cn_s, tok_s, w_s = torch.ops.escha.escham_moe_build_chunks(
                        top_k_index.to(torch.long), top_k_weights.float(), E)
                    _, xh2 = torch.ops.escha.escham_moe_linear_swiglu_t(
                        x16, self._gu_tr_ptrs, self._gu_rin, self._gu_rout, self._gu_ain,
                        self._gu_aout, re_s, ce_s, cr0_s, cn_s, tok_s,
                        2 * I, self._gu_K, self._moe_cbA, self._moe_mul1,
                        self._dp_rin, self._dp_ain)
                    if self._det_scatter():
                        out = torch.ops.escha.escham_moe_linear_scatter_prehad_det(
                            xh2, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain,
                            self._dp_aout, re_s, ce_s, cr0_s, cn_s,
                            tok_s, w_s, N,
                            H, self._dp_K, self._moe_cbA, self._moe_mul1, None)
                    else:
                        out = torch.ops.escha.escham_moe_linear_scatter_prehad(
                            xh2, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain,
                            self._dp_aout, re_s, ce_s, cr0_s, cn_s,
                            tok_s, w_s, N,
                            H, self._dp_K, self._moe_cbA, self._moe_mul1)
                    return out.to(hidden_states.dtype)
                _, xh2 = torch.ops.escha.escham_moe_linear_swiglu_t(
                    x16, self._gu_tr_ptrs, self._gu_rin, self._gu_rout, self._gu_ain,
                    self._gu_aout, flat_expert, ce_t, rows, cn_t, flat_token,
                    2 * I, self._gu_K, self._moe_cbA, self._moe_mul1,
                    self._dp_rin, self._dp_ain)
                if self._det_scatter():
                    out = torch.ops.escha.escham_moe_linear_scatter_prehad_det(
                        xh2, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain,
                        self._dp_aout, flat_expert, ce_t, rows, cn_t,
                        flat_token, flat_weight.float(), N,
                        H, self._dp_K, self._moe_cbA, self._moe_mul1, None)
                else:
                    out = torch.ops.escha.escham_moe_linear_scatter_prehad(
                        xh2, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain,
                        self._dp_aout, flat_expert, ce_t, rows, cn_t,
                        flat_token, flat_weight.float(), N,
                        H, self._dp_K, self._moe_cbA, self._moe_mul1)
                return out.to(hidden_states.dtype)
            h = torch.ops.escha.escham_moe_linear_swiglu(
                x16, self._gu_tr_ptrs, self._gu_rin, self._gu_rout, self._gu_ain,
                self._gu_aout, flat_expert, ce_t, rows, cn_t, flat_token,
                2 * I, self._gu_K, self._moe_cbA, self._moe_mul1)
            out = torch.ops.escha.escham_moe_linear_scatter(
                h, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain,
                self._dp_aout, flat_expert, ce_t, rows, cn_t,
                flat_token, flat_weight.float(), N,
                H, self._dp_K, self._moe_cbA, self._moe_mul1)
            return out.to(hidden_states.dtype)

        flat_token = flat_token if flat_token.dtype == torch.long else flat_token.long()
        xg = hidden_states.index_select(0, flat_token).to(torch.float16).contiguous()
        gu = op(xg, self._gu_tr_ptrs, self._gu_rin, self._gu_rout, self._gu_ain, self._gu_aout,
                flat_expert, ce_t, rows, cn_t, 2 * I, self._gu_K, self._moe_cbA, self._moe_mul1)
        gated = self._apply_gate(gu).to(torch.float16).contiguous()
        d = op(gated, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain, self._dp_aout,
               flat_expert, ce_t, rows, cn_t, H, self._dp_K, self._moe_cbA, self._moe_mul1)
        d = d * flat_weight[:, None].to(d.dtype)
        out = torch.zeros_like(hidden_states)
        out.index_add_(0, flat_token, d.to(out.dtype))
        return out

    @torch.no_grad()
    def _forward_fused_oom_safe(self, hidden_states: torch.Tensor, top_k_index: torch.Tensor,
                                top_k_weights: torch.Tensor, _min_rows: int = 8) -> torch.Tensor:
        """`_forward_escha_moe_fused`, but a transient OOM degrades instead of killing the server.

        SGLang's scheduler has NO per-request recovery for a forward-pass exception: anything
        that escapes `run_event_loop` reaches the top-level handler, which SIGQUITs the parent
        (`scheduler.py`). So on a memory-tight card one unlucky batch shape took down the whole
        endpoint, and every other in-flight request with it -- measured on a 16 GB RTX 5060 Ti at
        `MEM=0.94`, ISL 1024 / OSL 1024 / bs 16 (2026-07-27). Re-raising cannot help, whatever the
        exception type; the fix has to stop it escaping.

        Each token's MoE output depends only on its own row and its own routed experts, so
        splitting the token dimension and concatenating is numerically equivalent at a lower peak
        footprint. (Not bit-identical in general: a split can drop below the 64-row threshold and
        take the capturable path, which sums in a different order. Both are correct; this only
        happens on the OOM path, where the alternative is a dead server.) On OOM we free the cached
        blocks and retry in halves, recursively, down to `_min_rows`. Cost is paid ONLY on the
        failure path -- the normal path is the single fused call, untouched.
        """
        try:
            return self._forward_escha_moe_fused(hidden_states, top_k_index, top_k_weights)
        except torch.OutOfMemoryError:
            n = hidden_states.shape[0]
            # Never retry mid-capture: allocating and branching during CUDA-graph capture is
            # itself illegal, and an OOM there is a startup/capture failure (fix it with MEM or
            # CUDA_GRAPH_BS), not a per-request spike worth degrading for.
            if torch.cuda.is_current_stream_capturing():
                logger.error(
                    "escha MoE OOM during CUDA-graph capture (rows=%d) — lower MEM or drop the "
                    "largest entry from CUDA_GRAPH_BS", n)
                raise
            if n <= _min_rows:
                logger.error(
                    "escha MoE OOM at the minimum split (rows=%d, hidden=%d, experts=%d, "
                    "top_k=%d) — genuinely out of memory; lower MEM or CTXLEN",
                    n, hidden_states.shape[-1], self.num_experts, top_k_index.shape[-1])
                raise
            torch.cuda.empty_cache()
            half = n // 2
            logger.warning(
                "escha MoE OOM at rows=%d (hidden=%d, experts=%d, top_k=%d) — retrying in "
                "2 chunks of ~%d. The request is slower but the server stays up; if this "
                "recurs, lower MEM (0.92 is the tested 16 GB value) or CTXLEN.",
                n, hidden_states.shape[-1], self.num_experts, top_k_index.shape[-1], half)
            parts = [
                self._forward_fused_oom_safe(
                    hidden_states[s], top_k_index[s], top_k_weights[s], _min_rows)
                for s in (slice(0, half), slice(half, n))
            ]
            return torch.cat(parts, dim=0)

    def _forward_escha_moe_fused(self, hidden_states: torch.Tensor, top_k_index: torch.Tensor,
                                 top_k_weights: torch.Tensor) -> torch.Tensor:
        """Fused escham_moe: route -> gather -> grouped gate_up GEMV (merged code, OC=2I)
        -> SwiGLU -> grouped down GEMV -> weighted scatter. 2 custom launches/Linear
        (had_in + gemv + epi) over ALL experts' tokens at once, vs per-expert."""
        import escha  # noqa: F401
        op = torch.ops.escha.escham_moe_linear
        if getattr(self, "_escha_built", None) is None:
            self._build_escha_moe()
        # Decode/capture sizes → sync-free fixed-shape per-row path (CUDA-graph capturable).
        # Large N (prefill, eager) → chunked path below (decodes once per <=8-row expert group).
        if hidden_states.shape[0] <= 64:
            return self._forward_escha_moe_capturable(hidden_states, top_k_index, top_k_weights, op)
        H, I, E = self.hidden_size, self.intermediate_size, self.num_experts
        dev = hidden_states.device
        token_sorted, weight_sorted, expert_count = _sort_by_expert(
            top_k_index, top_k_weights, E)
        counts = expert_count[:E]
        cl = counts.tolist()                                               # single D2H sync
        M = sum(cl)
        token_sorted = token_sorted[:M].contiguous()
        weight_sorted = weight_sorted[:M].contiguous()
        row_expert = torch.repeat_interleave(
            torch.arange(E, device=dev), counts).contiguous()              # [M] int64
        # <=8-row per-expert chunks (CPU build from counts; mostly-empty experts skip
        # cheaply — measured faster than the vectorized torch-op path at decode sizes).
        ce, cr0, cn = [], [], []
        cursor = 0
        for e in range(E):
            c = cl[e]
            s = 0
            while s < c:
                n = 8 if c - s >= 8 else c - s
                ce.append(e); cr0.append(cursor + s); cn.append(n); s += n
            cursor += c
        ce_t = torch.tensor(ce, dtype=torch.int32, device=dev)
        cr_t = torch.tensor(cr0, dtype=torch.int32, device=dev)
        cn_t = torch.tensor(cn, dtype=torch.int32, device=dev)
        xg = hidden_states.index_select(0, token_sorted).to(torch.float16).contiguous()
        gu = op(xg, self._gu_tr_ptrs, self._gu_rin, self._gu_rout, self._gu_ain, self._gu_aout,
                row_expert, ce_t, cr_t, cn_t, 2 * I, self._gu_K, self._moe_cbA, self._moe_mul1)
        gated = self._apply_gate(gu).to(torch.float16).contiguous()
        d = op(gated, self._dp_tr_ptrs, self._dp_rin, self._dp_rout, self._dp_ain, self._dp_aout,
               row_expert, ce_t, cr_t, cn_t, H, self._dp_K, self._moe_cbA, self._moe_mul1)
        d = d * weight_sorted[:, None].to(d.dtype)
        final = torch.zeros_like(hidden_states)
        final.index_add_(0, token_sorted, d.to(final.dtype))
        return final

    def _forward_loop(self, hidden_states: torch.Tensor, top_k_index: torch.Tensor,
                      top_k_weights: torch.Tensor) -> torch.Tensor:
        final_hidden_states = torch.zeros_like(hidden_states)
        with torch.no_grad():
            mask = F.one_hot(top_k_index, num_classes=self.num_experts).permute(2, 1, 0)
            hit = torch.greater(mask.sum(dim=(-1, -2)), 0).nonzero()
        for ei in hit:
            e = int(ei[0])
            if e == self.num_experts:
                continue
            top_k_pos, token_idx = torch.where(mask[e])
            cur = hidden_states[token_idx]
            gate_up = self.gate_up_experts[f"gate_up_proj_{e}"](cur)
            gated = self._apply_gate(gate_up)
            out = self.down_experts[f"down_proj_{e}"](gated)
            weighted = out * top_k_weights[token_idx, top_k_pos, None]
            final_hidden_states.index_add_(0, token_idx, weighted.to(final_hidden_states.dtype))
        return final_hidden_states

    def trainable_parameters(self):
        """Yield the E2E-trainable per-expert scales (codes stay frozen)."""
        for m in list(self.gate_up_experts.values()) + list(self.down_experts.values()):
            yield m.s_in
            yield m.s_out
            if m.bcorr is not None:
                yield m.bcorr
