"""TCQEschaLinear — escha sibling class storing ESCHAM-quantized weights.

Drop-in replacement for nn.Linear, sister to EschaBinaryLinear and
EschaAdditiveLinear. Used when escha's ``code_family="escham"`` flag is set.

Two storage modes:

  1. ``deploy_recons`` (default, RECOMMENDED): reconstructs the deploy-
     equivalent dense fp16 weight at construction time using the REF path
     (raw code decode → transform → rin/rout, all in fp16). Stores the
     resulting bf16 dense weight. Forward is plain ``F.linear``.

     Why this is the right default: REF's deployed inference does the same
     reconstruct chain. Our previous default used
     ``quantize_ref(return_weight_q=True)`` which computes in fp32 and
     differs from the deploy weight by up to 0.1% per-element
     (per REF's own test tolerance, test_quant_fn.py:178). That
     discrepancy is benign on 1.7B (28 layers) but compounds catastrophically
     on 8B (36 layers × hidden 4096): PPL 2500-6300 vs target ~10-12.

  2. ``rtq`` (runtime-quantize, faithful to REF's hgemm path): stores
     code + rin + rout + the raw fp16 code-decoded weight, applies
     transform at runtime per-forward. Mathematically equivalent to (1) but
     does the transform fresh each call — useful for E2E where we want
     gradients flowing through the transform. Heavier per-forward.

Storage (deploy_recons mode):
  - ``q_weight``  (buffer, bf16)   [OC, IC]   — fp16-precision reconstructed weight
  - ``bias_buf``  (buffer, bf16)   [OC]
  - ``s_out``     (Parameter, fp32) [OC]      — per-output-row scale  (trainable in E2E)
  - ``s_in``      (Parameter, fp32) [IC]      — per-input-column scale (trainable in E2E)

Forward (both modes):
  y = (x * s_in) @ q_weight^T * s_out + bias_buf

For ``rtq`` mode the ``q_weight`` is replaced with the on-the-fly path.
"""

from __future__ import annotations

import logging
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from escha.transform import escha_t128, reconstruct_code

logger = logging.getLogger(__name__)


def reconstruct_deploy_weight(
    code: torch.Tensor,
    rin: torch.Tensor,
    rout: torch.Tensor,
    in_features: int,
    out_features: int,
    K: int,
    cbA: bool,
    mul1: bool,
    harp_rot_in=None,
    harp_rot_out=None,
) -> torch.Tensor:
    """Reconstruct the deploy-equivalent fp16 dense weight (IC, OC).

    Raw code decode → preapply_had_l → *rin → preapply_had_r → *rout. All
    in fp16 internally (except the transform mults which use fp32 inside
    ``escha_t128`` then cast back). This is the deploy-equivalent reconstruction;
    the quantize.py ``return_weight_q=True`` path does the same chain in fp32
    and yields a slightly different result (0.1% per-element) — don't use it
    for deploy weights.

    ``harp_rot_in`` / ``harp_rot_out`` optionally replace the fixed block-128
    transform with a fitted learned butterfly (``escha_official/harp.py``). None
    — the default, and what every existing checkpoint produces — keeps this
    function bit-identical to its previous behaviour. This is the path that
    makes a learned rotation measurable end-to-end with no kernel work: the
    in-process ``escha`` dense fallback reconstructs through here.

    Returns: fp16 tensor (IC, OC).
    """
    # 1. Raw code decode → fp16 (IC, OC)
    w = reconstruct_code(code, in_features, out_features, K, cbA, mul1)
    # 2. preapply_had_l: transform along the IC axis, block size 128 — reshapes
    #    w into (IC/128, 128, OC) and matmuls by H_128 from the left. Equivalent
    #    to escha_t128 applied along the *first* axis. We transpose to apply
    #    along last dim, then transpose back.
    if harp_rot_in is None:
        w = escha_t128(w.t().contiguous()).t().contiguous()
    else:
        w = harp_rot_in.inverse_left(w.float()).to(torch.float16)
    # 3. *rin (per-IC fp16 scale, broadcast over OC)
    w = w * rin.unsqueeze(1)
    # 4. preapply_had_r: transform along OC axis, block size 128. Last-dim
    #    layout matches escha_t128 directly.
    if harp_rot_out is None:
        w = escha_t128(w)
    else:
        w = harp_rot_out.inverse_right(w.float()).to(torch.float16)
    # 5. *rout (per-OC fp16 scale, broadcast over IC)
    w = w * rout.unsqueeze(0)
    return w


class TCQEschaLinear(nn.Module):
    """Quantized linear backed by a ESCHAM codec (BlockLDLQ + Viterbi)."""

    # Marker attribute checked by EschaModifier._run_e2e_finetune and other
    # escha machinery that needs to dispatch on code family.
    code_family: str = "escham"

    def __init__(
        self,
        q_weight: torch.Tensor,
        bias: Optional[torch.Tensor],
        *,
        dtype: torch.dtype = torch.bfloat16,
    ) -> None:
        """Direct construction from a pre-built dense weight.

        Callers that have the code tensors should prefer
        :meth:`from_code` instead — it builds the deploy-equivalent weight
        in-place and avoids the precision-mismatch trap that the default
        ``return_weight_q=True`` path falls into.
        """
        super().__init__()
        if q_weight.dim() != 2:
            raise ValueError(f"q_weight must be 2D [OC, IC]; got {tuple(q_weight.shape)}")
        OC, IC = q_weight.shape
        self.out_features = OC
        self.in_features = IC

        self.register_buffer("q_weight", q_weight.to(dtype=dtype, copy=True).contiguous())

        if bias is not None:
            self.register_buffer("bias_buf", bias.to(dtype=dtype, copy=True).contiguous())
        else:
            self.register_buffer("bias_buf", None, persistent=False)

        param_device = self.q_weight.device
        self.s_out = nn.Parameter(torch.ones(OC, dtype=torch.float32, device=param_device))
        self.s_in = nn.Parameter(torch.ones(IC, dtype=torch.float32, device=param_device))

    @classmethod
    def from_code_runtime(
        cls,
        code: torch.Tensor,
        rin: torch.Tensor,
        rout: torch.Tensor,
        bias: Optional[torch.Tensor],
        *,
        in_features: int,
        out_features: int,
        K: int,
        cbA: bool,
        mul1: bool,
        dtype: torch.dtype = torch.bfloat16,
    ) -> "TCQEschaLinear":
        """Build a TCQEschaLinear that does runtime transform at forward time.

        Matches REF's ``reconstruct_hgemm`` line-for-line: store the bare
        code-decoded weight (no transform, no rin/rout baked in), then at
        forward apply ``y = had_r(x * rin) @ w_bare; y = had_r(y) * rout``.

        This is THE PATH THAT REF AND ESCHA DEPLOY. The "baked unwound dense
        weight" path (the original :meth:`from_code`) is mathematically
        equivalent in fp32 but the bf16 rounding behavior differs — and the
        baked path uses REF's test-only ``return_weight_q=True`` code which
        REF's own tests admit differs by up to 0.1%/element from the deploy
        path. Use this variant to match REF's deploy precision exactly.
        """
        # Decode bare code weight once: shape (IC, OC) fp16. Used by the
        # runtime-transform forward path (pure-torch reconstruct + matmul).
        w_bare = reconstruct_code(code, in_features, out_features, K, cbA, mul1)
        # For PyTorch nn.Linear convention we'd want (OC, IC) but runtime here
        # uses (IC, OC) directly with `xh @ w_bare`. Keep IC×OC layout.
        instance = cls.__new__(cls)
        nn.Module.__init__(instance)
        instance.out_features = out_features
        instance.in_features = in_features
        instance._runtime_had = True
        # w_bare + had_r in PyTorch: used for both E2E gradient training and
        # inference — the runtime-transform forward is unconditional in this
        # build (no fused-CUDA-kernel dispatch).
        instance.register_buffer("code", code.contiguous())  # (IC//16, OC//16, 16*K) int16
        instance.register_buffer("w_bare", w_bare.contiguous())  # (IC, OC) fp16
        instance.register_buffer("rin_buf", rin.to(torch.half).contiguous())
        instance.register_buffer("rout_buf", rout.to(torch.half).contiguous())
        instance._K = int(K)
        instance._cbA = bool(cbA)
        instance._mul1 = bool(mul1)
        if bias is not None:
            instance.register_buffer("bias_buf", bias.to(dtype=dtype, copy=True).contiguous())
        else:
            instance.register_buffer("bias_buf", None, persistent=False)
        # No q_weight in runtime mode — w_bare carries the actual weight content.
        # Register as None so getattr returns None (not AttributeError) and the
        # integration's NaN check correctly inspects w_bare via the _runtime_had
        # branch. Saves ~100-200 MB per Linear at 8B (critical for fitting in
        # 24 GB VRAM).
        instance.register_buffer("q_weight", None, persistent=False)
        param_device = w_bare.device
        instance.s_out = nn.Parameter(torch.ones(out_features, dtype=torch.float32, device=param_device))
        instance.s_in = nn.Parameter(torch.ones(in_features, dtype=torch.float32, device=param_device))
        return instance

    @classmethod
    def from_code(
        cls,
        code: torch.Tensor,
        rin: torch.Tensor,
        rout: torch.Tensor,
        bias: Optional[torch.Tensor],
        *,
        in_features: int,
        out_features: int,
        K: int,
        cbA: bool,
        mul1: bool,
        dtype: torch.dtype = torch.bfloat16,
    ) -> "TCQEschaLinear":
        """Build TCQEschaLinear from quantize_ref's deploy tensors.

        Uses the REF deploy-equivalent reconstruction (matches
        ``LinearREF.get_weight_tensor()`` line for line) rather than
        ``return_weight_q=True``'s fp32 path. This fixes the
        compounding-error bug that made 8B catastrophic.
        """
        w_fp16 = reconstruct_deploy_weight(
            code, rin, rout, in_features, out_features, K, cbA, mul1,
        )
        # Convert (IC, OC) → (OC, IC) for PyTorch layout, cast to dtype.
        q_weight = w_fp16.t().contiguous()
        return cls(q_weight, bias, dtype=dtype)

    # ------------------------------------------------------------------ forward
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if getattr(self, "_runtime_had", False):
            return self._forward_runtime_had(x)
        x_dtype = x.dtype
        s_in = self.s_in.to(x_dtype)
        s_out = self.s_out.to(x_dtype)
        y = F.linear(x * s_in, self.q_weight, None)
        y = y * s_out
        if self.bias_buf is not None:
            y = y + self.bias_buf
        return y

    def _forward_runtime_had(self, x: torch.Tensor) -> torch.Tensor:
        """Deploy-equivalent forward: runtime transform against bare code.

            xh = escha_t128(x * rin)
            y_ = xh @ w_bare
            y  = escha_t128(y_) * rout + bias

        Activations are cast to fp16 and the result is cast back to
        ``x.dtype`` at the boundary. Mathematically equivalent to the baked
        path but does the transform at runtime, against the bare
        code-decoded weight (not the unwound dense weight).
        """
        x_dtype = x.dtype
        s_in = self.s_in.to(x_dtype)
        s_out = self.s_out.to(x_dtype)
        # Do the matmul in x.dtype (typically bf16). REF's deploy kernel
        # uses fp16, but for Qwen3-8B's L16 attention sink (FP norm ~9000),
        # the post-rot post-quant intermediates can exceed fp16's 65504 →
        # inf → NaN cascade. bf16 has same range as fp32, immune to overflow,
        # at the cost of slightly lower precision (3 fewer mantissa bits) —
        # negligible vs 2bpw quantization noise.
        rin = self.rin_buf.to(x_dtype)
        rout = self.rout_buf.to(x_dtype)
        w_bare = self.w_bare.to(x_dtype)
        xh = escha_t128(x * s_in, pre_scale=rin)
        y_ = xh @ w_bare  # (..., OC), x_dtype
        y = escha_t128(y_, post_scale=rout)
        y = y * s_out
        if self.bias_buf is not None:
            y = y + self.bias_buf
        return y

    # ----------------------------------------------------------------- helpers
    @property
    def weight(self) -> torch.Tensor:
        """Effective dequantised weight (q_weight folded with scales).

        Returned as bf16 so callers can use it as a drop-in nn.Linear.weight
        substitute for tests/diagnostics. Not used by forward.
        """
        if getattr(self, "_runtime_had", False):
            # Reconstruct on-the-fly from w_bare + rin + rout (the deploy chain).
            # w_bare is (IC, OC); reconstruct using same recipe but starting
            # from w_bare directly instead of decoding code again.
            w = escha_t128(self.w_bare.t().contiguous()).t().contiguous()
            w = w * self.rin_buf.unsqueeze(1)
            w = escha_t128(w)
            w = w * self.rout_buf.unsqueeze(0)
            # (IC, OC) → (OC, IC) for PyTorch convention, fold s_in/s_out.
            w_pt = w.t().contiguous().to(self.rin_buf.dtype)
            s_in = self.s_in.to(w_pt.dtype)
            s_out = self.s_out.to(w_pt.dtype)
            return w_pt * s_out.unsqueeze(1) * s_in.unsqueeze(0)
        s_in = self.s_in.to(self.q_weight.dtype)
        s_out = self.s_out.to(self.q_weight.dtype)
        return self.q_weight * s_out.unsqueeze(1) * s_in.unsqueeze(0)

    @property
    def bias(self) -> Optional[torch.Tensor]:
        return self.bias_buf

    def extra_repr(self) -> str:
        return (
            f"in_features={self.in_features}, out_features={self.out_features}, "
            f"bias={self.bias_buf is not None}, code_family=escham"
        )

    # --------------------------------------------------------------- E2E API
    def e2e_trainable_params(self) -> list[nn.Parameter]:
        """Return parameters E2E should make trainable."""
        return [self.s_out, self.s_in]
