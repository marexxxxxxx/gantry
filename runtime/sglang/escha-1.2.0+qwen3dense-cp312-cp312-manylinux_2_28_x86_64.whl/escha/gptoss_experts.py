"""Packed-codes (memory-frugal) gpt-oss MoE experts for E2E fine-tuning.

The resident bf16-W2 gpt-oss model is ~40GB; on a 44.4GB-usable L40S that leaves
no room for E2E backprop. This module stores each expert's quantized weight as
its **2-bit code codes** (~5MB/expert vs ~33MB bf16) and **decodes on the fly**
each forward, so the whole model's experts fit in ~6-7GB and E2E can train the
tiny per-expert ``s_in``/``s_out`` scales (+ optional ``bcorr``) within budget.

The code codes are FROZEN; gradient flows only to the trainable scales, which
are applied *after* the (non-differentiable) decode — so a CUDA decode kernel is
fine. The forward replicates ``TCQEschaLinear._forward_runtime_had`` (the
REF-deploy chain ``y = had_r(x·s_in·rin) @ w_bare; y = had_r(y)·rout·s_out``) and
``GptOssExperts.forward`` (interleaved clamped-SwiGLU routing) so it is
numerically equivalent to the bf16 eager path (verified to bf16 noise).

gpt-oss padding: IC=2880 is not a multiple of the ref transform width (128), so
weights were quantized zero-padded to 3072. Each ``PackedScaledExpertLinear``
holds the padded codes and pads x / truncates y around the decode.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from escha.transform import reconstruct_code, escha_t128

# The decode-and-matmul path (reconstruct_code + escha_t128) is used
# unconditionally in this build: it is differentiable (E2E trains the
# s_in/s_out scales) AND, since reconstruct_code now dispatches to
# escha-kernels' own escham_reconstruct CUDA op, dependency-free. There is no
# separate non-differentiable fast-inference kernel in this build.


class PackedScaledExpertLinear(nn.Module):
    """One expert projection backed by frozen code codes (decode-on-the-fly)
    + trainable ``s_in``/``s_out`` (+ optional ``bcorr``).

    Stores codes for the padded dims (in_p, out_p); the real dims (in_f, out_f)
    drive the x-pad / y-truncate. ``s_in``/``s_out`` live on the REAL dims so the
    optimizer trains only meaningful DOF (padded rows/cols are inert)."""

    def __init__(self, code, rin, rout, bias, *, in_f, out_f, in_p, out_p,
                 K, cbA, mul1, bias_correction=False):
        super().__init__()
        self.in_features, self.out_features = int(in_f), int(out_f)
        self.in_p, self.out_p = int(in_p), int(out_p)
        self._K, self._cbA, self._mul1 = int(K), bool(cbA), bool(mul1)
        self.register_buffer("code", code.contiguous())          # int16 codes (padded)
        self.register_buffer("rin_buf", rin.reshape(-1).to(torch.float16).contiguous())  # [in_p]
        self.register_buffer("rout_buf", rout.reshape(-1).to(torch.float16).contiguous())  # [out_p]
        if bias is not None:
            self.register_buffer("bias_buf", bias.to(torch.bfloat16).contiguous())       # [out_f]
        else:
            self.register_buffer("bias_buf", None, persistent=False)
        self.s_in = nn.Parameter(torch.ones(self.in_features, dtype=torch.float32))
        self.s_out = nn.Parameter(torch.ones(self.out_features, dtype=torch.float32))
        self.bcorr = (nn.Parameter(torch.zeros(self.out_features, dtype=torch.float32))
                       if bias_correction else None)

    @torch.no_grad()
    def _decode(self) -> torch.Tensor:
        """Decode the frozen code to the bare weight (in_p, out_p) fp16. No grad."""
        return reconstruct_code(self.code, self.in_p, self.out_p,
                                   self._K, self._cbA, self._mul1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (n, in_features). Pad to in_p; scale padded cols by s_in=1 (inert).
        x_dtype = x.dtype
        if self.in_p != self.in_features:
            xp = x.new_zeros((*x.shape[:-1], self.in_p))
            xp[..., :self.in_features] = x * self.s_in.to(x_dtype)
        else:
            xp = x * self.s_in.to(x_dtype)
        w_bare = self._decode().to(x_dtype)                  # (in_p, out_p), frozen
        xh = escha_t128(xp, pre_scale=self.rin_buf.to(x_dtype))   # (n, in_p)
        y = xh @ w_bare                                      # (n, out_p)
        y = escha_t128(y, post_scale=self.rout_buf.to(x_dtype))    # (n, out_p)
        y = y.to(x_dtype)[..., :self.out_features]               # truncate to real OC
        y = y * self.s_out.to(x_dtype)
        if self.bcorr is not None:
            y = y + self.bcorr.to(x_dtype)
        if self.bias_buf is not None:
            y = y + self.bias_buf
        return y


def _round_up(n: int, m: int = 128) -> int:
    return ((n + m - 1) // m) * m


class PackedGptOssExperts(nn.Module):
    """Drop-in for ``GptOssExperts`` whose per-expert projections are
    :class:`PackedScaledExpertLinear` (frozen codes + trainable scales). Forward
    mirrors ``GptOssExperts.forward`` / ``GptOssExpertShim.forward`` exactly
    (interleaved clamped SwiGLU, per-token routing) so it slots into the eager
    ``GptOssMLP.forward`` for E2E training."""

    _is_gptoss_packed = True

    def __init__(self, layer_codes: dict, cfg, *, bias_correction=False):
        """``layer_codes`` = the saved per-layer codes dict (see quant --save-codes):
        for each expert e, gate_up/down (code, rin, rout, bias, K, codebook)."""
        super().__init__()
        self.num_experts = int(cfg.num_local_experts)
        self.hidden_size = int(cfg.hidden_size)
        self.intermediate_size = int(cfg.intermediate_size)
        self.alpha = float(getattr(cfg, "alpha", 1.702))
        self.limit = float(getattr(cfg, "limit", 7.0))
        H, I = self.hidden_size, self.intermediate_size
        Hp, Ip2 = _round_up(H), _round_up(2 * I)
        self.gate_up_experts = nn.ModuleDict()
        self.down_experts = nn.ModuleDict()
        for e in range(self.num_experts):
            gu = layer_codes[f"gate_up_proj_{e}"]
            dp = layer_codes[f"down_proj_{e}"]
            cbA = gu["codebook"] == "cbA"; mul1 = gu["codebook"] == "mul1"
            self.gate_up_experts[f"gate_up_proj_{e}"] = PackedScaledExpertLinear(
                gu["code"], gu["rin"], gu["rout"], gu.get("bias"),
                in_f=H, out_f=2 * I, in_p=Hp, out_p=_round_up(2 * I),
                K=gu["K"], cbA=cbA, mul1=mul1, bias_correction=bias_correction)
            self.down_experts[f"down_proj_{e}"] = PackedScaledExpertLinear(
                dp["code"], dp["rin"], dp["rout"], dp.get("bias"),
                in_f=I, out_f=H, in_p=_round_up(I), out_p=_round_up(H),
                K=dp["K"], cbA=(dp["codebook"] == "cbA"), mul1=(dp["codebook"] == "mul1"),
                bias_correction=bias_correction)

    def _apply_gate(self, gate_up: torch.Tensor) -> torch.Tensor:
        gate, up = gate_up[..., ::2], gate_up[..., 1::2]
        gate = gate.clamp(min=None, max=self.limit)
        up = up.clamp(min=-self.limit, max=self.limit)
        glu = gate * torch.sigmoid(gate * self.alpha)
        return (up + 1) * glu

    def forward(self, hidden_states, router_indices, routing_weights):
        next_states = torch.zeros_like(hidden_states)
        with torch.no_grad():
            mask = F.one_hot(router_indices, num_classes=self.num_experts).permute(2, 1, 0)
            hit = torch.greater(mask.sum(dim=(-1, -2)), 0).nonzero()
        for ei in hit:
            e = int(ei[0])
            if e == self.num_experts:
                continue
            top_k_pos, token_idx = torch.where(mask[e])
            cur = hidden_states[token_idx]
            gate_up = self.gate_up_experts[f"gate_up_proj_{e}"](cur)
            gated = self._apply_gate(gate_up)
            out = self.down_experts[f"down_proj_{e}"](gated)
            weighted = out * routing_weights[token_idx, top_k_pos, None]
            next_states.index_add_(0, token_idx, weighted.to(next_states.dtype))
        return next_states

    def trainable_parameters(self):
        for m in list(self.gate_up_experts.values()) + list(self.down_experts.values()):
            yield m.s_in
            yield m.s_out
            if m.bcorr is not None:
                yield m.bcorr
