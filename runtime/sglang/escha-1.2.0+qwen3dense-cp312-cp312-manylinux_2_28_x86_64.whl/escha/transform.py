"""Code-decode + block-transform transform helpers for ESCHAM deploy weights.

Storage format: packed tail-biting code + rin/rout incoherence scales.
At forward time: ``y = had_r(x * rin) @ w_code_decoded; y = had_r(y) * rout``
— the deploy-equivalent reconstruction chain used throughout the ESCHAM line.

``reconstruct_code`` decodes via escha-kernels' own CUDA op
(``escham_reconstruct``); ``escha_t128`` is a pure-PyTorch block-transform.
"""

from __future__ import annotations

import functools
import math
import os
import sys
from typing import Optional

import torch


def reconstruct_code(
    code: torch.Tensor,
    in_features: int,
    out_features: int,
    K: int,
    cbA: bool,
    mul1: bool,
) -> torch.Tensor:
    """Decode a packed code to its raw fp16 dense weight (IC, OC).

    No transform, no rin/rout applied — just the code lookup.
    """
    return torch.ops.escha.escham_reconstruct(code, in_features, out_features, K, cbA, mul1)


# === transform transform (blockwise size 128) ============================
#
# Applies a size-128 transform transform to each 128-block of the last dim,
# optionally pre-multiplying by a scale and post-multiplying by a scale (one
# or the other, not both). Pure PyTorch, dtype-agnostic — used unconditionally
# (no CUDA-extension fast path in this build).

@functools.lru_cache(maxsize=8)
def _transform_128(device: str, dtype: torch.dtype) -> torch.Tensor:
    """Normalized Sylvester transform of size 128."""
    h = torch.tensor([[1.0]], dtype=torch.float32)
    while h.shape[0] < 128:
        h = torch.cat([torch.cat([h, h], dim=1), torch.cat([h, -h], dim=1)], dim=0)
    h = h / math.sqrt(128.0)
    return h.to(device=device, dtype=dtype)


def escha_t128(
    x: torch.Tensor,
    pre_scale: Optional[torch.Tensor] = None,
    post_scale: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Apply ``y = post_scale * Had_128_block(x * pre_scale)`` along the last dim.

    Either pre_scale or post_scale may be None; passing both is supported
    but typically only one is used per call.

    Shapes:
      x: (..., IC) where IC % 128 == 0
      pre_scale: (IC,) or None
      post_scale: (IC,) or None
    """
    IC = x.shape[-1]
    if IC % 128 != 0:
        raise ValueError(f"escha_t128: last dim {IC} must be divisible by 128")
    if pre_scale is not None:
        x = x * pre_scale
    # Reshape so the 128 axis is contiguous; apply transform via matmul.
    leading = x.shape[:-1]
    x = x.reshape(*leading, IC // 128, 128)
    had = _transform_128(x.device, x.dtype)
    x = torch.matmul(x, had)  # (..., IC/128, 128)
    x = x.reshape(*leading, IC)
    if post_scale is not None:
        x = x * post_scale
    return x
