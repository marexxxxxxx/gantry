from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import torch

from sglang.jit_kernel.utils import KERNEL_PATH, cache_once, load_jit, make_cpp_args

if TYPE_CHECKING:
    from tvm_ffi.module import Module


@cache_once
def _jit_transform_module(dtype: torch.dtype) -> Module:
    args = make_cpp_args(dtype)
    transform_include_dir = (KERNEL_PATH / "csrc" / "fast-transform-transform").resolve()
    return load_jit(
        "transform",
        *args,
        cuda_files=["fast-transform-transform/transform_jit.cuh"],
        cuda_wrappers=[
            ("transform_transform", f"transformKernel<{args}>::run"),
            ("transform_transform_12n", f"transform12NKernel<{args}>::run"),
            ("transform_transform_20n", f"transform20NKernel<{args}>::run"),
            ("transform_transform_28n", f"transform28NKernel<{args}>::run"),
            ("transform_transform_40n", f"transform40NKernel<{args}>::run"),
        ],
        extra_include_paths=[str(transform_include_dir)],
    )


def _transform_transform_impl(
    x: torch.Tensor,
    scale: float,
    pad_multiple: int,
    kernel_fn: Callable,
) -> torch.Tensor:
    if not x.is_cuda:
        raise RuntimeError(f"{kernel_fn.__name__} only supports CUDA tensors")

    shapes_og = x.size()
    dim_og = x.size(-1)
    x = x.reshape(-1, dim_og)
    if x.stride(-1) != 1:
        x = x.contiguous()

    needs_pad = dim_og % pad_multiple != 0
    if needs_pad:
        x = torch.nn.functional.pad(x, (0, pad_multiple - dim_og % pad_multiple))

    out = torch.empty_like(x)
    kernel_fn(x, out, scale)

    if needs_pad:
        out = out[:, :dim_og]
    return out.reshape(shapes_og)


def transform_transform(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    module = _jit_transform_module(x.dtype)
    return _transform_transform_impl(x, scale, 8, module.transform_transform)


def transform_transform_12n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    module = _jit_transform_module(x.dtype)
    return _transform_transform_impl(x, scale, 4 * 12, module.transform_transform_12n)


def transform_transform_20n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    module = _jit_transform_module(x.dtype)
    return _transform_transform_impl(x, scale, 4 * 20, module.transform_transform_20n)


def transform_transform_28n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    module = _jit_transform_module(x.dtype)
    return _transform_transform_impl(x, scale, 4 * 28, module.transform_transform_28n)


def transform_transform_40n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    module = _jit_transform_module(x.dtype)
    return _transform_transform_impl(x, scale, 4 * 40, module.transform_transform_40n)
